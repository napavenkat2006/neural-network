import os

def generate_answer(message, context=""):
    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key:
        if context:
            return (
                "Gemini API key is not configured yet. Based on the local music "
                "knowledge base, here is the relevant information:\n\n" + context
            )
        return (
            "Gemini API key is not configured. Add GEMINI_API_KEY to your environment "
            "and restart the application."
        )

    try:
        from google import genai

        client = genai.Client(api_key=api_key)
        prompt = f"""
You are MusicGPT, a helpful music assistant.

Use the supplied knowledge-base context when it is relevant. Do not invent facts.
If the context is insufficient, clearly say that and answer generally.

Knowledge-base context:
{context or "No matching context was found."}

User question:
{message}

Give a concise, useful answer.
"""
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt
        )
        return response.text
    except Exception as exc:
        return f"AI service error: {exc}"
