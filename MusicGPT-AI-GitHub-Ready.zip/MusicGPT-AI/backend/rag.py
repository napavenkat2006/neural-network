from pathlib import Path
import re

DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "music_knowledge.txt"

def _chunks(text, size=900):
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks = []
    for p in paragraphs:
        if len(p) <= size:
            chunks.append(p)
        else:
            for i in range(0, len(p), size):
                chunks.append(p[i:i + size])
    return chunks

def _score(query, chunk):
    words = set(re.findall(r"[a-zA-Z0-9']+", query.lower()))
    target = chunk.lower()
    return sum(1 for word in words if len(word) > 2 and word in target)

def retrieve_context(query, top_k=3):
    if not DATA_FILE.exists():
        return ""
    text = DATA_FILE.read_text(encoding="utf-8")
    chunks = _chunks(text)
    ranked = sorted(chunks, key=lambda c: _score(query, c), reverse=True)
    useful = [c for c in ranked[:top_k] if _score(query, c) > 0]
    return "\n\n".join(useful)
