# 🎵 MusicGPT AI

MusicGPT is a GitHub-ready AI music assistant built with **Python, Flask, Google Gemini, and a lightweight RAG pipeline**.

## Features

- AI music assistant
- Google Gemini integration
- Retrieval-Augmented Generation (RAG)
- Local music knowledge base
- Flask REST API
- HTML/CSS/JavaScript frontend
- Responsive chat interface
- No database required for the starter version

## Project Structure

```text
MusicGPT-AI/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── backend/
│   ├── __init__.py
│   ├── rag.py
│   └── llm.py
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── data/
│   └── music_knowledge.txt
├── vectorstore/
│   └── .gitkeep
└── assets/
```

## 1. Clone the repository

```bash
git clone https://github.com/YOUR-USERNAME/MusicGPT-AI.git
cd MusicGPT-AI
```

## 2. Create a virtual environment

### Windows

```bash
python -m venv .venv
.venv\Scripts\activate
```

### macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
```

## 3. Install dependencies

```bash
pip install -r requirements.txt
```

## 4. Configure Gemini

Create an environment variable named `GEMINI_API_KEY`.

### Windows PowerShell

```powershell
$env:GEMINI_API_KEY="YOUR_API_KEY"
```

### macOS/Linux

```bash
export GEMINI_API_KEY="YOUR_API_KEY"
```

**Never commit your real API key to GitHub.**

## 5. Run

```bash
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

## API

### POST `/api/chat`

Request:

```json
{
  "message": "What is jazz?"
}
```

Response:

```json
{
  "answer": "..."
}
```

## RAG Flow

```text
User Question
      ↓
Flask API
      ↓
Local Knowledge Base
      ↓
Relevant Context Retrieval
      ↓
Gemini
      ↓
AI Response
      ↓
Web Interface
```

## GitHub Upload

```bash
git init
git add .
git commit -m "Initial MusicGPT AI project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/MusicGPT-AI.git
git push -u origin main
```

## Future Improvements

- Replace keyword retrieval with embeddings
- Add ChromaDB or FAISS
- Add Spotify API integration
- Add authentication
- Add conversation memory
- Add music recommendations
- Add song/artist search
- Deploy using Render, Railway, or another cloud platform

## License

MIT License
