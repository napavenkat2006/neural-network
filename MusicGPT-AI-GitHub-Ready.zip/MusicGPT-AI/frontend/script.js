const form = document.getElementById("chat-form");
const input = document.getElementById("message");
const chat = document.getElementById("chat");
const button = form.querySelector("button");

function addMessage(text, type) {
  const box = document.createElement("div");
  box.className = `message ${type}`;

  const title = document.createElement("strong");
  title.textContent = type === "user" ? "You" : "MusicGPT";

  const body = document.createElement("p");
  body.textContent = text;

  box.appendChild(title);
  box.appendChild(body);
  chat.appendChild(box);
  chat.scrollTop = chat.scrollHeight;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const message = input.value.trim();
  if (!message) return;

  addMessage(message, "user");
  input.value = "";
  button.disabled = true;

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({message})
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Request failed");
    }

    addMessage(data.answer, "bot");
  } catch (error) {
    addMessage(`Error: ${error.message}`, "bot");
  } finally {
    button.disabled = false;
    input.focus();
  }
});
